#include "Battery.h"
#include <Arduino.h>

#define BATTERY_PIN A0       // Battery pin (ADC pin) on ESP8266
#define MAX_VOLTAGE 4.2      // Fully charged voltage of Li-ion battery
#define MIN_VOLTAGE 3.0      // Minimum voltage before the battery is considered empty

// The ESP8266's ADC is typically scaled from 0 to 1023 for 0 to 1V. 
// We need to map that to the actual battery voltage.
#define ADC_MAX_VALUE 1023   // Maximum ADC value
#define ADC_REF_VOLTAGE 1.0  // Reference voltage for ADC (assuming 1.0V for ESP8266 ADC)

// Function to initialize battery sensor (set up the ADC pin)
void setupBattery() {
  pinMode(BATTERY_PIN, INPUT);
}

// Function to calculate battery percentage
String getBatteryPercentage() {
  int adcValue = analogRead(BATTERY_PIN);  // Read ADC value
  float voltage = (adcValue / float(ADC_MAX_VALUE)) * ADC_REF_VOLTAGE;  // Convert to voltage
  
  // Adjust for actual battery voltage (use a voltage divider if needed)
  voltage *= (MAX_VOLTAGE / ADC_REF_VOLTAGE);

  // Calculate percentage based on voltage
  float percentage = ((voltage - MIN_VOLTAGE) / (MAX_VOLTAGE - MIN_VOLTAGE)) * 100;

  // Clamp the result between 0% and 100%
  if (percentage > 100) percentage = 100;
  if (percentage < 0) percentage = 0;

  // Return battery percentage as a string
  char buffer[10];
  snprintf(buffer, sizeof(buffer), "%.2f %%", percentage);
  return String(buffer);  // Use char buffer to minimize memory overhead
}
