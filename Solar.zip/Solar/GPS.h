#ifndef GPS_H
#define GPS_H

#include <TinyGPS++.h>
#include <SoftwareSerial.h>

extern TinyGPSPlus gps;
extern SoftwareSerial ss;

void setupGPS();  // Function to initialize GPS
String getGPSData();  // Function to get GPS data (lat, lon, timestamp)

#endif
