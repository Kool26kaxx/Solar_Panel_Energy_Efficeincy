#ifndef BATTERY_H
#define BATTERY_H

#include <Arduino.h>  // Add this to enable String type

void setupBattery();
String getBatteryPercentage();

#endif
