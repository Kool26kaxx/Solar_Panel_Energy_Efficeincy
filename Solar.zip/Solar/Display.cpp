#include "Display.h"

// Define the I2C address if it's not the default one
#define SSD1306_I2C_ADDRESS 0x3C  // or 0x3D depending on your screen

// Initialize OLED display
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// Set up the display (this will run once in the setup)
void setupDisplay() {
  if (!display.begin(SSD1306_SWITCHCAPVCC, SSD1306_I2C_ADDRESS)) {  // Use the manually defined I2C address
    Serial.println(F("SSD1306 allocation failed"));
    for (;;);
  }
  display.display();  // Initialize with an empty screen
  delay(2000);  // Wait for a while to show the initial screen
  display.clearDisplay();  // Clear the screen for the first update
}


// Update display based on mode and data
void updateDisplay(DisplayMode mode, String gpsData, String bmeData, String ina219Data, String batteryData, String dateTime, String deviceID) {
  display.clearDisplay();  // Clear previous data

  // Set font size and position
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);

  // Display device ID at the top
  display.print("Device ID: ");
  display.println(deviceID);
  
  // Based on mode, display the corresponding data
  switch (mode) {
    case DATE_TIME:
      display.println("Date & Time:");
      display.println(dateTime);  // Display the current date and time
      break;

    case INA219:
      display.println("INA219 Data:");
      display.println(ina219Data);
      break;

    case BME280:
      display.println("BME280 Data:");
      display.println(bmeData);
      break;
      
    case BATTERY:
      display.println("Battery:");
      display.println(batteryData);
      break;
    
    case GPS:
      display.println("GPS Data:");
      display.println(gpsData);
      break;    
    
  }

  display.display();  // Update the OLED display with the new data
}
