#include "INA219.h"
#include <Adafruit_INA219.h>

// Create an instance of the INA219 sensor
Adafruit_INA219 ina219;

void setupINA219() {
  if (!ina219.begin()) {
    Serial.println("Could not find a valid INA219 sensor.");
    while (1);
  }
  Serial.println("INA219 sensor initialized.");
}

String getINA219Data() {
  float voltage = ina219.getBusVoltage_V();  // Bus voltage in volts
  float current = ina219.getCurrent_mA();    // Current in milliamps
  float power = ina219.getPower_mW();        // Power in milliwatts

  // Return a single string that contains INA219 data (Voltage, Current, Power)
  return String(voltage, 2) + " V, " + String(current, 2) + " mA, " + String(power, 2) + " mW";
}
