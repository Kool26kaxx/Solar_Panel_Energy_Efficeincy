#ifndef INA219_H
#define INA219_H

#include <Wire.h>
#include <Adafruit_INA219.h>

extern Adafruit_INA219 ina219;  // INA219 sensor object

void setupINA219();  // Function to initialize INA219 sensor
String getINA219Data();  // Function to get INA219 data (Voltage, Current, Power)

#endif
