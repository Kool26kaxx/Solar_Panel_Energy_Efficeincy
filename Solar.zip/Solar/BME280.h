#ifndef BME280_H
#define BME280_H

#include <Adafruit_Sensor.h>
#include <Adafruit_BME280.h>

extern Adafruit_BME280 bme;  // BME280 sensor object

void setupBME280();  // Function to initialize BME280 sensor
String getBME280Data();  // Function to get sensor data (Temperature, Humidity, Pressure)

#endif
