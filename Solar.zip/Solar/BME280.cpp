#include "BME280.h"
#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BME280.h>

// Create an instance of the BME280 sensor
Adafruit_BME280 bme;

void setupBME280() {
  // Use the correct I2C address for your BME280 sensor
  if (!bme.begin(0x76)) {  // If your sensor is at address 0x76 (default is 0x77)
    Serial.println("Could not find a valid BME280 sensor.");
    while (1);  // Halt here if sensor is not found
  }
  Serial.println("BME280 sensor initialized.");
}

String getBME280Data() {
  // Read the sensor values
  float temperature = bme.readTemperature();  // Get temperature in Celsius
  float humidity = bme.readHumidity();        // Get humidity in percentage
  float pressure = bme.readPressure() / 100.0F;  // Get pressure in hPa

  // Return a formatted string with sensor data
  return String(temperature, 2) + " C, " + String(humidity, 2) + " %, " + String(pressure, 2) + " hPa";
}
