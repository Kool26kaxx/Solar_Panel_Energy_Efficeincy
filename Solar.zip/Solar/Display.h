#ifndef DISPLAY_H
#define DISPLAY_H

#include <Adafruit_SSD1306.h>
#include <Wire.h>
#include <ESP8266WiFi.h>

// OLED Display settings
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
extern Adafruit_SSD1306 display;

// Enum for different display modes
enum DisplayMode {
  GPS,
  BME280,
  INA219,
  BATTERY,
  DATE_TIME
};

// Function declarations
void setupDisplay();
void updateDisplay(DisplayMode mode, String gpsData, String bmeData, String ina219Data, String batteryData, String dateTime, String deviceID);

#endif
