#include "GPS.h"
#include <SoftwareSerial.h>

TinyGPSPlus gps;
SoftwareSerial ss(4, 5);  // GPS TX -> D2 (GPIO4), RX -> D1 (GPIO5)

void setupGPS() {
  ss.begin(9600);  // Initialize GPS with 9600 baud rate
  Serial.begin(115200);  // Start Serial communication for debugging
}

String getGPSData() {
  while (ss.available() > 0) {
    gps.encode(ss.read());  // Clear the buffer and process incoming GPS data
  }

  // Check if we have a valid GPS fix
  if (gps.location.isUpdated()) {
    double lat = gps.location.lat();
    double lon = gps.location.lng();
    String timestamp = String(gps.date.year()) + "-" + String(gps.date.month()) + "-" + String(gps.date.day()) + " " +
                       String(gps.time.hour()) + ":" + String(gps.time.minute()) + ":" + String(gps.time.second());

    // Return a single string that contains GPS data (combined lat, lon, timestamp)
    return String(lat, 6) + ", " + String(lon, 6) + ", " + timestamp;
  }

  // If no valid GPS fix, return an error message
  return "No fix available";
}
